/// @ref core
/// @file glm/vec2.hpp

#pragma once

#include "detail/type_vec2.hpp"
